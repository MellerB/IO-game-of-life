package com.example.inzynieria_oprogramowania
import android.graphics.Canvas
import android.graphics.Paint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.MotionEvent
import android.view.View
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        customView.setOnTouchListener { v, event ->
            when (event?.action) {
                MotionEvent.ACTION_DOWN -> println(event.getX().toString().plus(" ").plus(event.getY()))
            }

            v?.onTouchEvent(event) ?: true
        }

        val displayMetrics: DisplayMetrics = DisplayMetrics()
        val eldo = windowManager.defaultDisplay.getMetrics(displayMetrics)

        var width = displayMetrics.widthPixels
        var height = displayMetrics.heightPixels


        while (width != height)
        {
            if (width > height)
                width -= height
            else
                height -= width
        }

        println(width)
        println(height)
    }
}
