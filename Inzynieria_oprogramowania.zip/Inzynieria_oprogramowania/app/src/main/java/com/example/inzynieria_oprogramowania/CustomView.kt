package com.example.inzynieria_oprogramowania

import android.R
import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.widget.PopupWindow

class CustomView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0) : View(context, attrs, defStyleAttr)
{
    private val strokeSize=10f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth=strokeSize
        textAlign = Paint.Align.CENTER
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        strokeWidth=strokeSize
        setColor(Color.WHITE)
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)


        var board:Board=Board(8,8)
        var hei=height/board.rows
        var wid=width/board.columns

        for(j in 1 until board.columns)
        {
            canvas.drawLine(wid.toFloat()*j,0f,wid.toFloat()*j,height.toFloat(),paint)
            canvas.drawLine(0f,hei.toFloat()*j,width.toFloat(),hei.toFloat()*j,paint)
        }
        canvas.drawRect(wid.toFloat()+strokeSize,hei.toFloat()+strokeSize,2*wid.toFloat()-strokeSize,2*hei.toFloat()-strokeSize,fill)

    }




}




