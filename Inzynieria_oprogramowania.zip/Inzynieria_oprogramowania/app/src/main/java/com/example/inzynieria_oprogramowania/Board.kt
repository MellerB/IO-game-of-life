package com.example.inzynieria_oprogramowania

import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.constraintlayout.solver.LinearSystem

public class Board(var rows:Int, var columns:Int)
{

    var matrix : Array<BooleanArray> = Array(rows) { BooleanArray(columns)}
}

